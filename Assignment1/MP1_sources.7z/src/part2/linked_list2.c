#include "linked_list2.h"

void 	Init (int M, int b, int t){} 
void 	Destroy (){} 		 
int 	Insert (int key,char * value_ptr, int value_len){}
int 	Delete (int key){}
char* 	Lookup (int key){}
void 	PrintList (){}

