#include <stdio.h>
#include "linked_list.h"

void 	Init (int M, int b){} 
void 	Destroy (){} 		 
int 	Insert (int key,char * value_ptr, int value_len){}
int 	Delete (int key){}
char* 	Lookup (int key){return NULL;}
void 	PrintList (){}